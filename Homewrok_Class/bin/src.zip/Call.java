
public class Call {	
	
		static final  double priceForAMinute = 0.5;
		int caller;
		int receiver;
		int duration;
	
	}
