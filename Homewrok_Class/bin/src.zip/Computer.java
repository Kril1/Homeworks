
public class Computer {

	int year;
	double price;
	boolean isNotebook;
	int hardDiskMemory;
	int freeMemory;
	String operationSystem;

	public String changeOperationSystem(String newOS) {

		this.operationSystem=newOS;
		
		return operationSystem;
	}

	public void useMemory (int memoryUsed){
		if (this.freeMemory - memoryUsed >= 0){
			this.freeMemory -= memoryUsed;
		}else{
			System.out.println("Not enough free memory!");
		}
		
	}
}
